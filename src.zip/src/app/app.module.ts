import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';import { AppComponent } from './app.component';
import { VolComponent } from './vol/vol.component';
import {VolService} from './vol.service';
import {HebergementService}from './hebergement.service';
import { Routes,RouterModule } from '@angular/router';
import { HebergementComponent } from './hebergement/hebergement.component';
import {HttpClientModule} from '@angular/common/http';

const appRoutes: Routes = [
  { path: 'vols', component: VolComponent },
  { path: 'hebergements', component: HebergementComponent }

];

@NgModule({
  declarations: [
    AppComponent,
    VolComponent,
    HebergementComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [VolService,HebergementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
